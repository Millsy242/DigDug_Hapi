/*
	HAPI Start
	----------
	This solution contains an already set up HAPI project and this main file

	The directory structure and main files are:

	HAPI_Start - contains the Visual Studio solution file (.sln)
		HAPI_Start - contains the Visual Studio HAPI_APP project file (.vcxproj) and source code
			HAPI - the directory with all the HAPI library files
			Data - a place to put your data files with a few sample ones provided

	Additionally in the top directory there are two batch files for creating a redistributable Demo folder
*/

// Include the HAPI header to get access to all of HAPIs interfaces
#include <HAPI_lib.h>

// HAPI itself is wrapped in the HAPISPACE namespace
using namespace HAPISPACE;

inline void ClearToColour(BYTE *screen, int screenWidth, int screenHeight, HAPI_TColour colour);
inline void settocolour(BYTE *screen, int screenWidth, int x, int y, HAPI_TColour colour);

struct star
{
	float x, y, z;
	float r, g, b;
	HAPI_TColour colour;
};

// Every HAPI program has a HAPI_Main as an entry point
// When this function exits the program will close down
void HAPI_Main()
{
	int width{ 800 };
	int height{ 600 };

	int Cx = width / 2;
	int Cy = height / 2;

	float eyeDistance{ 100 };

	if (!HAPI.Initialise(width, height, "Feeling Happy - Stars"))
		return;

	BYTE* screen = HAPI.GetScreenPointer();
	HAPI.SetShowFPS(true, 0, 0, HAPI_TColour::MAGENTA);
	HAPI.SetShowCursor(false);

	unsigned int numstars{ 1000000 };
	star *stars = new star[numstars];

	for (unsigned int i{ 0 }; i < numstars; i++)
	{
		stars[i].x = rand() % width;
		stars[i].y = rand() % height;
		stars[i].z = rand() % 500;

		stars[i].r = rand() % 255;
		stars[i].g = rand() % 255;
		stars[i].b = rand() % 255;

		stars[i].colour = HAPI_TColour(stars[i].r, stars[i].g, stars[i].b);
		//stars[i].colour = HAPI_TColour::WHITE;
	}

	while (HAPI.Update()) //returns true until user closes window
	{
		ClearToColour(screen, width, height, HAPI_TColour::BLACK);

		HAPI_TMouseData mdata = HAPI.GetMouseData();
		const HAPI_TKeyboardData &kdata = HAPI.GetKeyboardData();

		if (kdata.scanCode[HK_LEFT]) //left arrow
			eyeDistance += 0.25;
		if (kdata.scanCode[HK_RIGHT]) //right arrow
			eyeDistance -= 0.25;
		if (kdata.scanCode[HK_SPACE])
			eyeDistance = 100;

		if (eyeDistance <= 1)
			eyeDistance = 1;
		if (eyeDistance >= 10000)
			eyeDistance = 10000;

		Cx = mdata.x;
		Cy = mdata.y;
		for (unsigned int i{ 0 }; i < numstars; i++)
		{

			float Sx = ((eyeDistance*(stars[i].x - Cx)) / (stars[i].z + eyeDistance)) + Cx;

			float Sy = ((eyeDistance*(stars[i].y - Cy)) / (stars[i].z + eyeDistance)) + Cy;

			if (Sx >= width)
				Sx = (float)width - 1;
			if (Sy >= height)
				Sy = (float)height - 1;

			stars[i].z -= 0.4f;

			if (stars[i].z <= 0)
				stars[i].z = 500;

			settocolour(screen, width, (int)Sx, (int)Sy, stars[i].colour);
		}
	}
	delete[] stars;
}

void ClearToColour(BYTE *screen, int screenWidth, int screenHeight, HAPI_TColour colour)
{
	if (colour == HAPI_TColour::BLACK) //Better Performance
		memset(screen, 0, screenWidth*screenHeight * 4);
	else
	{
		for (int i{ 0 }; i < (screenWidth*screenHeight); i++)
		{
			screen[i * 4] = colour.red;
			screen[i * 4 + 1] = colour.green;
			screen[i * 4 + 2] = colour.blue;
		}
	}
}

void settocolour(BYTE *screen, int screenWidth, int x, int y, HAPI_TColour colour)
{
	unsigned int offset = (x + y*screenWidth) * 4;

	screen[offset] = colour.red;
	screen[offset + 1] = colour.green;
	screen[offset + 2] = colour.blue;
}